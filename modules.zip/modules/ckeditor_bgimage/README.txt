CkEditor Background Image
